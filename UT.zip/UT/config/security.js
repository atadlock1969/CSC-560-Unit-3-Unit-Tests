module.exports = {
    stormpath_secret_key : ‘YOUR STORMPATH APPLICATION KEY’;
}

