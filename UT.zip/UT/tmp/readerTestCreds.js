TEST_USERS = 
[{	"_id":"54ad6c3ae764de42070b27b1",
	"email":"testuser1@example.com",
	"firstName":"Test",
	"lastName":"User1",
	"sp_api_key_id":"<API KEY ID>",
	"sp_api_key_secret":”<API KEY SECRET>”
},
{	"_id":"54ad6c3be764de42070b27b2",
	"email":"testuser2@example.com",
	"firstName":"Test",
	"lastName":"User2",
	"sp_api_key_id":”<API KEY ID>",
	"sp_api_key_secret":”<API KEY SECRET>”
}];
module.exports = TEST_USERS;


