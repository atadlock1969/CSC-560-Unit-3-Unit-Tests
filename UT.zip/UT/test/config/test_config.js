module.exports = {
    url : 'http://localhost:8000/api/v1.0'
}